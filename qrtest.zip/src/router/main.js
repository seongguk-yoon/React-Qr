import Navigation from "../Navigation";
import Qrcode from "../QRcode";

function Main() {
  return (
    <div>
      <Navigation />
      <Qrcode />
    </div>
  );
}

export default Main;