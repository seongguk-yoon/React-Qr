import Navigation from "../Navigation";
import Qrscantest from "../QRreader";

function Qrscan() {
  return (
    <div>
      <Navigation />
      <Qrscantest />
    </div>
  );
}

export default Qrscan;